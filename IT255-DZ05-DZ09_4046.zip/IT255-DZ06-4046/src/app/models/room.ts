export interface Room {

  id?: number;
  title?: string;
  imageUrl?: string;
  price?: number;
}
